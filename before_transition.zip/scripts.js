(() => {
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  const carousel = document.querySelector("[data-carousel]");
  if (!carousel) return;

  const slides = Array.from(carousel.querySelectorAll("[data-slide]"));
  const prevButton = document.querySelector("[data-carousel-prev]");
  const nextButton = document.querySelector("[data-carousel-next]");
  const dotsHost = carousel.querySelector("[data-carousel-dots]");

  if (!slides.length || !prevButton || !nextButton || !dotsHost) return;

  let activeIndex = slides.findIndex((slide) => slide.classList.contains("is-active"));
  if (activeIndex < 0) activeIndex = 0;

  const dots = slides.map((_, index) => {
    const dot = document.createElement("button");
    dot.type = "button";
    dot.className = "carousel-dot";
    dot.setAttribute("aria-label", `Go to testimonial slide ${index + 1}`);
    dot.addEventListener("click", () => showSlide(index));
    dotsHost.appendChild(dot);
    return dot;
  });

  function showSlide(index) {
    activeIndex = (index + slides.length) % slides.length;

    slides.forEach((slide, slideIndex) => {
      slide.classList.toggle("is-active", slideIndex === activeIndex);
      slide.setAttribute("aria-hidden", slideIndex === activeIndex ? "false" : "true");
    });

    dots.forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === activeIndex);
      dot.setAttribute("aria-pressed", dotIndex === activeIndex ? "true" : "false");
    });
  }

  prevButton.addEventListener("click", () => showSlide(activeIndex - 1));
  nextButton.addEventListener("click", () => showSlide(activeIndex + 1));

  showSlide(activeIndex);

  let autoplay = window.setInterval(() => showSlide(activeIndex + 1), 5500);

  carousel.addEventListener("mouseenter", () => {
    window.clearInterval(autoplay);
  });

  carousel.addEventListener("mouseleave", () => {
    autoplay = window.setInterval(() => showSlide(activeIndex + 1), 5500);
  });
})();
